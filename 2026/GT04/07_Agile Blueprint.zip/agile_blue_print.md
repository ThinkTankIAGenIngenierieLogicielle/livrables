# Agile BluePrint

The objective is to suggest the agile structure from a specification : sprint, user stories, points, risks, tasks, teams and tasks assignement.

## Files
1) [agile_blueprint_prompt.md](agile_blueprint_prompt.md), the prompt analyzing a specification and generating the agile project structure in JSON format
2) [agile_blue_print_visualizer.html](agile_blue_print_visualizer.html), a single page webapplication displaying the JSON format (can be ran locally). Generated in Vibe Coding with Gemini Canvas.
3) [sample_of_output.json](sample_of_output.json), an sample of JSON resulting from the analysis of a real specifications
## Screenshot

1) loading the json file
![](./screenshot_loading_json.png)
2) Short description and sprints visualization
![](./screenshot_sprints.png)
3) User stories and associated tasks
![](./screenshot_user_stories.png)
4) Risks assessment
![](./screenshot_risks.png)
5) Suggested team
![](./screenshot_team.png)
